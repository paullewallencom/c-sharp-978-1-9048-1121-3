using System;

namespace Chapter8_WebService
{
	interface IHelloWorldService
	{
      string GetHelloWorldMessage(string name);
	}
}
