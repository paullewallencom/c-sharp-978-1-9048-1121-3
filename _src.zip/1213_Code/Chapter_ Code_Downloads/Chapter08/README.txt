Programming Windows Workflow Foundation - Chapter 8
---------------------------------------------------

Files listed in the folder are used in the chapter as sample scripts and files.

Use the files as described in the Chapter 8 of the book.