using System;
using System.Workflow.Activities;

namespace chapter2_library
{
	public sealed partial class PureCode: SequentialWorkflowActivity
	{
		public PureCode()
		{
			InitializeComponent();
		}

      private void codeActivity1_ExecuteCode(object sender, EventArgs e)
      {
      
      }
	}
}
