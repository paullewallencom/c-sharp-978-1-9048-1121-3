using System;
using System.Workflow.Activities;

namespace chapter2_library
{
	public partial class CodeSeparation : 
      SequentialWorkflowActivity
	{
      private void codeActivity1_ExecuteCode(object sender, EventArgs e)
      {

      }
   }
}
