Programming Windows Workflow Foundation - Book Downloads
--------------------------------------------------------

This folder contains the following two sub-folders:

1. Chapter_Code_Downloads
2. Project_Code

-------------------------
1. Chapter_Code_Downloads
-------------------------

Various sample scripts are used in each chapter of the Programming Windows Workflow Foundation Book. This folder contains sub-folders for individual chapters containing all the required files.

---------------
2. Project_Code
---------------

This folder contains all the files required to bring up the sample workflow project as per the Programming Windows Workflow Foundation Book.


